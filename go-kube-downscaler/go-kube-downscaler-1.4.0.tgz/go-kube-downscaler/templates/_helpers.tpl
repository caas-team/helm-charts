{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "go-kube-downscaler.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "go-kube-downscaler.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
If replicaCount is greater than 1, leader election is enabled by default.
*/}}
{{- define "go-kube-downscaler.leaderElection" -}}
{{- if gt (.Values.replicaCount | int) 1 -}}true{{- else -}}false{{- end -}}
{{- end }}

{{/*
Return true if "gateways" is present in .Values.includedResources
*/}}
{{- define "go-kube-downscaler.deployGatewayClass" -}}
{{- if and (hasKey .Values "includedResources") (contains "gateways" (toJson .Values.includedResources)) -}}
true
{{- end -}}
{{- end }}

{{/*
Return true if "ingresses" is present in .Values.includedResources
*/}}
{{- define "go-kube-downscaler.deployIngressClass" -}}
{{- if and (hasKey .Values "includedResources") (contains "ingresses" (toJson .Values.includedResources)) -}}
true
{{- end -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "go-kube-downscaler.labels" -}}
helm.sh/chart: {{ include "go-kube-downscaler.chart" . }}
{{ include "go-kube-downscaler.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "go-kube-downscaler.selectorLabels" -}}
application: {{ include "go-kube-downscaler.fullname" . }}
{{- end }}


{{/*
Create the name of the service account to use
*/}}
{{- define "go-kube-downscaler.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "go-kube-downscaler.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create webhook controller full name
*/}}
{{- define "go-kube-downscaler.webhookController.fullname" -}}
{{ include "go-kube-downscaler.fullname" . }}-webhook
{{- end }}

{{/*
Create the name of the webhook service account to use
*/}}
{{- define "go-kube-downscaler.webhookController.serviceAccountName" -}}
{{- if .Values.webhookController.serviceAccount.create }}
{{- default (include "go-kube-downscaler.webhookController.fullname" .) .Values.webhookController.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.webhookController.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create selector label for the webhook
*/}}
{{- define "go-kube-downscaler.webhookController.selectorLabels" -}}
application: {{ include "go-kube-downscaler.webhookController.fullname" . }}
{{- end }}


{{/*
Create defined permissions for the webhook role
*/}}
{{- define "go-kube-downscaler.webhookController.namespace.permissions" -}}
- apiGroups:
    - ""
  resources:
    - secrets
  verbs:
    - create
    - list
    - watch
- apiGroups:
    - ""
  resources:
    - secrets
  resourceNames:
    - {{ include "go-kube-downscaler.fullname" . }}-webhook
  verbs:
    - get
    - update
    - patch
- apiGroups:
    - coordination.k8s.io
  resources:
    - leases
  verbs:
    - get
    - create
    - watch
    - list
    - update
    - delete
{{- end }}

{{/*
Create defined permissions for the webhook clusterrole
*/}}
{{- define "go-kube-downscaler.webhookController.clusterwide-and-webhook.permissions" -}}
- apiGroups:
    - ""
  resources:
    - namespaces
  verbs:
    - get
- apiGroups:
    - admissionregistration.k8s.io
  resources:
    - mutatingwebhookconfigurations
  verbs:
    - list
    - watch
- apiGroups:
    - admissionregistration.k8s.io
  resources:
    - mutatingwebhookconfigurations
  resourceNames:
    - webhook.kube-downscaler.k8s
  verbs:
    - get
    - patch
    - update
{{- end }}
{{- define "go-kube-downscaler.webhookController.clusterwide.permissions" -}}
- apiGroups:
    - ""
  resources:
    - namespaces
  verbs:
    - get
    - list
- apiGroups:
    - ""
  resources:
    - events
  verbs:
    - get
    - create
    - update
{{- end }}

{{/*
Create defined permissions for roles
*/}}
{{- define "go-kube-downscaler.permissions" -}}
- apiGroups:
    - ""
  resources:
    - namespaces
  verbs:
    - get
- apiGroups:
    - ""
  resources:
    - events
  verbs:
    - get
    - create
    - update
{{- range $resource := .Values.includedResources }}
{{- if eq $resource "deployments" }}
- apiGroups:
    - apps
  resources:
    - deployments
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "statefulsets" }}
- apiGroups:
    - apps
  resources:
    - statefulsets
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "daemonsets" }}
- apiGroups:
    - apps
  resources:
    - daemonsets
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "rollouts" }}
- apiGroups:
    - argoproj.io
  resources:
    - rollouts
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "horizontalpodautoscalers" }}
- apiGroups:
    - autoscaling
  resources:
    - horizontalpodautoscalers
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "jobs" }}
- apiGroups:
    - batch
  resources:
    - jobs
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "cronjobs" }}
- apiGroups:
    - batch
  resources:
    - cronjobs
{{- if and (not (has "jobs" $.Values.includedResources)) (or (has "--scale-children" $.Values.arguments) (has "--scale-children=true" $.Values.arguments) (has "--scale-children" $.Values.extraArguments) (has "--scale-children=true" $.Values.extraArguments)) }}
    - jobs
{{- end }}
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "scaledobjects" }}
- apiGroups:
    - keda.sh
  resources:
    - scaledobjects
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "stacks" }}
- apiGroups:
    - zalando.org
  resources:
    - stacks
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "prometheuses" }}
- apiGroups:
    - monitoring.coreos.com
  resources:
    - prometheuses
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "poddisruptionbudgets" }}
- apiGroups:
    - policy
  resources:
    - poddisruptionbudgets
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "autoscalingrunnersets" }}
- apiGroups:
    - actions.github.com
  resources:
    - autoscalingrunnersets
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if or (eq $resource "services") (eq $resource "awselbservices") (eq $resource "awsnlbservices")}}
- apiGroups:
    - ""
  resources:
    - services
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "ingresses"}}
- apiGroups:
    - networking.k8s.io
  resources:
    - ingresses
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "gateways"}}
- apiGroups:
    - gateway.networking.k8s.io
  resources:
    - gateways
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "postgresqls" }}
- apiGroups:
    - acid.zalan.do
  resources:
    - postgresqls
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "kafkaconnects" }}
- apiGroups:
    - kafka.strimzi.io
  resources:
    - kafkaconnects
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "kafkamirrormaker2s" }}
- apiGroups:
    - kafka.strimzi.io
  resources:
    - kafkamirrormaker2s
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "kafkabridges" }}
- apiGroups:
    - kafka.strimzi.io
  resources:
    - kafkabridges
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "advancedstatefulsets" }}
- apiGroups:
    - apps.kruise.io
  resources:
    - statefulsets
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "clonesets" }}
- apiGroups:
    - apps.kruise.io
  resources:
    - clonesets
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "advancedcronjobs" }}
- apiGroups:
    - apps.kruise.io
  resources:
    - advancedcronjobs
{{- if and (not (has "broadcastjobs" $.Values.includedResources)) (or (has "--scale-children" $.Values.arguments) (has "--scale-children=true" $.Values.arguments) (has "--scale-children" $.Values.extraArguments) (has "--scale-children=true" $.Values.extraArguments)) }}
    - broadcastjobs
{{- end }}
{{- if and (not (has "imagepulljobs" $.Values.includedResources)) (or (has "--scale-children" $.Values.arguments) (has "--scale-children=true" $.Values.arguments) (has "--scale-children" $.Values.extraArguments) (has "--scale-children=true" $.Values.extraArguments)) }}
    - imagepulljobs
{{- end }}
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "broadcastjobs" }}
- apiGroups:
    - apps.kruise.io
  resources:
    - broadcastjobs
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "imagepulljobs" }}
- apiGroups:
    - apps.kruise.io
  resources:
    - imagepulljobs
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "advanceddaemonsets" }}
- apiGroups:
    - apps.kruise.io
  resources:
    - advanceddaemonsets
  verbs:
    - get
    - list
    - update
{{- end }}
{{- end }}
{{- end }}

{{/*
Create webhook resources
*/}}
{{- define "go-kube-downscaler.webhookresources" -}}
{{- range $resource := .Values.includedResources -}}
{{ if eq $resource "deployments" -}}
- apiGroups:
    - apps
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - deployments
{{ end -}}
{{ if eq $resource "statefulsets" -}}
- apiGroups:
    - apps
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - statefulsets
{{ end -}}
{{ if eq $resource "daemonsets" -}}
- apiGroups:
    - apps
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - daemonsets
{{ end -}}
{{ if eq $resource "rollouts" -}}
- apiGroups:
    - argoproj.io
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - rollouts
{{ end -}}
{{ if eq $resource "horizontalpodautoscalers" -}}
- apiGroups:
    - autoscaling
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - horizontalpodautoscalers
{{ end -}}
{{ if eq $resource "jobs" -}}
- apiGroups:
    - batch
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - jobs
{{ end -}}
{{ if eq $resource "cronjobs" -}}
- apiGroups:
    - batch
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - cronjobs
{{- if and (not (has "jobs" $.Values.includedResources)) (or (has "--scale-children" $.Values.arguments) (has "--scale-children=true" $.Values.arguments) (has "--scale-children" $.Values.extraArguments) (has "--scale-children=true" $.Values.extraArguments)) }}
    - jobs
{{- end }}
{{ end -}}
{{ if eq $resource "scaledobjects" -}}
- apiGroups:
    - keda.sh
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - scaledobjects
{{ end -}}
{{ if eq $resource "stacks" -}}
- apiGroups:
    - zalando.org
  resources:
    - stacks
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
{{ end -}}
{{ if eq $resource "prometheuses" -}}
- apiGroups:
    - monitoring.coreos.com
  resources:
    - prometheuses
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
{{ end -}}
{{ if eq $resource "poddisruptionbudgets" -}}
- apiGroups:
    - policy
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - poddisruptionbudgets
{{ end -}}
{{ if eq $resource "autoscalingrunnersets" -}}
- apiGroups:
    - actions.github.com
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - autoscalingrunnersets
{{ end -}}
{{ if eq $resource "postgresqls" -}}
- apiGroups:
    - acid.zalan.do
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - postgresqls
{{ end -}}
{{- if or (eq $resource "services") (eq $resource "awselbservices") (eq $resource "awsnlbservices")}}
- apiGroups:
    - ""
  resources:
    - services
  operations:
    - "CREATE"
    - "UPDATE"
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "ingresses" }}
- apiGroups:
    - "networking.k8s.io"
  resources:
    - ingresses
  operations:
    - "CREATE"
    - "UPDATE"
  verbs:
    - get
    - list
    - update
{{- end }}
{{- if eq $resource "gateways" }}
- apiGroups:
    - "gateway.networking.k8s.io"
  resources:
    - gateways
  operations:
    - "CREATE"
    - "UPDATE"
  verbs:
    - get
    - list
    - update
{{- end }}
{{ if eq $resource "kafkaconnects" -}}
- apiGroups:
    - kafka.strimzi.io
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - kafkaconnects
{{ end -}}
{{ if eq $resource "kafkamirrormaker2s" -}}
- apiGroups:
    - kafka.strimzi.io
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - kafkamirrormaker2s
{{ end -}}
{{ if eq $resource "kafkabridges" -}}
- apiGroups:
    - kafka.strimzi.io
  apiVersions:
    - "*"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - kafkabridges
{{ end -}}
{{ if eq $resource "advancedstatefulsets" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - statefulsets
{{ end -}}
{{ if eq $resource "clonesets" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - clonesets
{{ end -}}
{{ if eq $resource "advancedcronjobs" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - advancedcronjobs
{{- if and (not (has "broadcastjobs" $.Values.includedResources)) (or (has "--scale-children" $.Values.arguments) (has "--scale-children=true" $.Values.arguments) (has "--scale-children" $.Values.extraArguments) (has "--scale-children=true" $.Values.extraArguments)) }}
    - broadcastjobs
{{- end }}
{{- if and (not (has "imagepulljobs" $.Values.includedResources)) (or (has "--scale-children" $.Values.arguments) (has "--scale-children=true" $.Values.arguments) (has "--scale-children" $.Values.extraArguments) (has "--scale-children=true" $.Values.extraArguments)) }}
    - imagepulljobs
{{- end }}
{{ end -}}
{{ if eq $resource "broadcastjobs" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - broadcastjobs
{{ end -}}
{{ if eq $resource "imagepulljobs" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - imagepulljobs
{{ end -}}
{{ if eq $resource "advanceddaemonsets" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
    - "CREATE"
    - "UPDATE"
  resources:
    - advanceddaemonsets
{{ end -}}
{{ end -}}
{{- end }}


{{/*
resources include in annotationsCompliance
*/}}
{{- define "go-kube-downscaler.annotationsCompliance" -}}
{{- $createUpdate := .createUpdate | default false }}
{{- range $resource := .Values.includedResources -}}
{{ if eq $resource "deployments" -}}
- apiGroups:
    - apps
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - deployments
{{ end -}}
{{ if eq $resource "statefulsets" -}}
- apiGroups:
    - apps
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - statefulsets
{{ end -}}
{{ if eq $resource "daemonsets" -}}
- apiGroups:
    - apps
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - daemonsets
{{ end -}}
{{ if eq $resource "rollouts" -}}
- apiGroups:
    - argoproj.io
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - rollouts
{{ end -}}
{{ if eq $resource "horizontalpodautoscalers" -}}
- apiGroups:
    - autoscaling
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - horizontalpodautoscalers
{{ end -}}
{{ if eq $resource "jobs" -}}
- apiGroups:
    - batch
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - jobs
{{ end -}}
{{ if eq $resource "cronjobs" -}}
- apiGroups:
    - batch
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - cronjobs
{{- if and (not (has "jobs" $.Values.includedResources)) (or (has "--scale-children" $.Values.arguments) (has "--scale-children=true" $.Values.arguments) (has "--scale-children" $.Values.extraArguments) (has "--scale-children=true" $.Values.extraArguments)) }}
    - jobs
{{- end }}
{{ end -}}
{{ if eq $resource "scaledobjects" -}}
- apiGroups:
    - keda.sh
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - scaledobjects
{{ end -}}
{{ if eq $resource "stacks" -}}
- apiGroups:
    - zalando.org
  resources:
    - stacks
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
{{ end -}}
{{ if eq $resource "prometheuses" -}}
- apiGroups:
    - monitoring.coreos.com
  resources:
    - prometheuses
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
{{ end -}}
{{ if eq $resource "poddisruptionbudgets" -}}
- apiGroups:
    - policy
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - poddisruptionbudgets
{{ end -}}
{{ if eq $resource "autoscalingrunnersets" -}}
- apiGroups:
    - actions.github.com
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - autoscalingrunnersets
{{ end -}}
{{ if eq $resource "postgresqls" -}}
- apiGroups:
    - acid.zalan.do
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - postgresqls
{{ end -}}
{{ if eq $resource "kafkaconnects" -}}
- apiGroups:
    - kafka.strimzi.io
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - kafkaconnects
{{ end -}}
{{ if eq $resource "kafkamirrormaker2s" -}}
- apiGroups:
    - kafka.strimzi.io
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - kafkamirrormaker2s
{{ end -}}
{{ if eq $resource "kafkabridges" -}}
- apiGroups:
    - kafka.strimzi.io
  apiVersions:
    - "*"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - kafkabridges
{{ end -}}
{{ if eq $resource "advancedstatefulsets" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - statefulsets
{{ end -}}
{{ if eq $resource "clonesets" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - clonesets
{{ end -}}
{{ if eq $resource "advancedcronjobs" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
{{- if and (not (has "broadcastjobs" $.Values.includedResources)) (or (has "--scale-children" $.Values.arguments) (has "--scale-children=true" $.Values.arguments) (has "--scale-children" $.Values.extraArguments) (has "--scale-children=true" $.Values.extraArguments)) }}
    - broadcastjobs
{{- end }}
{{- if and (not (has "imagepulljobs" $.Values.includedResources)) (or (has "--scale-children" $.Values.arguments) (has "--scale-children=true" $.Values.arguments) (has "--scale-children" $.Values.extraArguments) (has "--scale-children=true" $.Values.extraArguments)) }}
    - imagepulljobs
{{- end }}
    - advancedcronjobs
{{ end -}}
{{ if eq $resource "broadcastjobs" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - broadcastjobs
{{ end -}}
{{ if eq $resource "imagepulljobs" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - imagepulljobs
{{ end -}}
{{ if eq $resource "advanceddaemonsets" -}}
- apiGroups:
    - apps.kruise.io
  apiVersions:
    - "v1beta1"
    - "v1alpha1"
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
  resources:
    - advanceddaemonsets
{{ end -}}
{{- if or (eq $resource "services") (eq $resource "awselbservices") (eq $resource "awsnlbservices")}}
- apiGroups:
    - ""
  apiVersions:
    - "*"
  resources:
    - services
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
{{- end }}
{{- if eq $resource "ingresses" }}
- apiGroups:
    - "networking.k8s.io"
  apiVersions:
    - "*"
  resources:
    - ingresses
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
{{- end }}
{{- if eq $resource "gateways" }}
- apiGroups:
    - "gateway.networking.k8s.io"
  apiVersions:
    - "*"
  resources:
    - gateways
  operations:
  {{- if $createUpdate }}
    - "CREATE"
  {{- end }}
    - "UPDATE"
{{- end }}
{{ end -}}
{{- end }}

{{/*
Validate annotationsCompliance combinations that JSON Schema cannot express.
*/}}
{{- define "go-kube-downscaler.annotationsCompliance.validate" -}}
{{- $enabled := or .Values.annotationsCompliance.onWorkloads.enabled .Values.annotationsCompliance.onNamespace.enabled .Values.annotationsCompliance.onWorkloads.preventRemoval .Values.annotationsCompliance.onNamespace.preventRemoval -}}
{{- if $enabled -}}
  {{- if and (or .Values.annotationsCompliance.onWorkloads.enabled .Values.annotationsCompliance.onWorkloads.preventRemoval) (eq (len .Values.includedResources) 0) -}}
    {{- fail "annotationsCompliance on workloads requires at least one includedResources entry" -}}
  {{- end -}}
  {{- if and (has "Deny" .Values.annotationsCompliance.validationActions) (has "Warn" .Values.annotationsCompliance.validationActions) -}}
    {{- fail "annotationsCompliance.validationActions cannot contain both Deny and Warn" -}}
  {{- end -}}
  {{- $conditionCount := add 2 (len .Values.annotationsCompliance.authorizedNamespacesToServiceAccountsRegex) (len .Values.annotationsCompliance.authorizedUsersRegex) (len .Values.annotationsCompliance.authorizedGroupsRegex) -}}
  {{- if gt ($conditionCount | int) 64 -}}
    {{- fail "annotationsCompliance configures more than Kubernetes' limit of 64 match conditions" -}}
  {{- end -}}
  {{- range $namespaceRegex, $serviceAccountRegex := .Values.annotationsCompliance.authorizedNamespacesToServiceAccountsRegex -}}
    {{- $_ := mustRegexMatch (printf "^system:serviceaccount:%s:%s" $namespaceRegex $serviceAccountRegex) "" -}}
  {{- end -}}
  {{- range $regex := .Values.annotationsCompliance.authorizedUsersRegex -}}
    {{- $_ := mustRegexMatch $regex "" -}}
  {{- end -}}
  {{- range $regex := .Values.annotationsCompliance.authorizedGroupsRegex -}}
    {{- $_ := mustRegexMatch $regex "" -}}
  {{- end -}}
{{- end -}}
{{- end }}
